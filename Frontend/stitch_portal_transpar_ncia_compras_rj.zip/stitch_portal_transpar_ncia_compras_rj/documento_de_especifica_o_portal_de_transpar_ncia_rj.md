# Projeto de Extensão: Transparência e Controle Social em Compras Diretas (Gov RJ 2023-2026)

## 1. Visão Geral do Objeto
- **Objeto**: Portal integrado de transparência ativa e auditoria cívica sobre contratações públicas diretas (isenções e dispensas pela Lei 14.133/2021) do Governo do Estado do Rio de Janeiro.
- **Dataset**: 19.676 registros de itens e R$ 17,03 bilhões aprovados entre 2023 e 2026 (origem: Compras RJ e TCE-RJ).
- **Stakeholders**: Sociedade civil, jornalistas investigativos, auditores cívicos, pesquisadores da UCP e cidadãos.

## 2. Pilares Metodológicos e Arquitetura
1. **Modelagem Relacional (Supabase / PostgreSQL)**: Star Schema com tabelas Fato Contratações e Dimensões (Fornecedor, Órgão, Categoria, Tempo). Connection pooling e SSL.
2. **Machine Learning Não Supervisionado**: K-Means (20 clusters validados por silhueta/cotovelo) + Isolation Forest para Score de Suspeição e anomalias de sobrepreço sem circularidade de rótulos.
3. **Analytics & BI**: Análise de Concentração de Pareto, Curvas de Preço Médio vs. Anomalia, Indicadores de Risco.
4. **Aplicação Web Pública**: Busca interativa, detalhamento de fornecedores, filtros por secretaria (Saúde, UERJ, Educação), painel de anomalias com justificativas explicáveis.
