---
name: Civic Data & Forensic Audit
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#43474d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#74777e'
  outline-variant: '#c3c6ce'
  surface-tint: '#49607c'
  primary: '#001428'
  on-primary: '#ffffff'
  primary-container: '#0f2942'
  on-primary-container: '#7991af'
  inverse-primary: '#b0c9e8'
  secondary: '#386380'
  on-secondary: '#ffffff'
  secondary-container: '#b2dcfe'
  on-secondary-container: '#37627f'
  tertiary: '#00170d'
  on-tertiary: '#ffffff'
  tertiary-container: '#002e1d'
  on-tertiary-container: '#21a173'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#b0c9e8'
  on-primary-fixed: '#011d35'
  on-primary-fixed-variant: '#314863'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#a1cced'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#1d4b67'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
  surface-canvas: '#F8FAFC'
  surface-card: '#FFFFFF'
  border-subtle: '#E2E8F0'
  border-strong: '#CBD5E1'
  risk-low: '#059669'
  risk-medium: '#D97706'
  risk-high: '#DC2626'
  risk-critical: '#991B1B'
  anomaly-flag: '#7C3AED'
  organ-health: '#0284C7'
  organ-education: '#EA580C'
  organ-uerj: '#0D9488'
  organ-police: '#334155'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
    letterSpacing: 0.01em
  metric-display:
    fontFamily: JetBrains Mono
    fontSize: 1.875rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.03em
  metric-value:
    fontFamily: JetBrains Mono
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.02em
  table-data:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.125rem
    letterSpacing: '0'
  code-badge:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

The design system embodies the rigor of public institutional oversight, investigative data journalism, and machine learning forensic analysis. Tailored for civic monitors, public prosecutors, data scientists, and citizens auditing public procurement across the State of Rio de Janeiro, the visual language balances unyielding institutional gravity with modern operational velocity.

The style converges **Corporate / Modern** governance with the information-dense utility of high-precision monitoring dashboards (drawing influence from technical analytical tooling and empirical civic observatories). It avoids decorative fluff in favor of structural clarity, high typographic fidelity, and contextual color-coding for anomaly detection (K-Means clusters, Isolation Forest anomaly rates, and Pareto distributions).

The user experience evokes absolute auditability, surgical objectivity, and calm authoritative reliability. Interface density is high but meticulously balanced, allowing civic auditors to cross-examine millions of Reais, supplier networks, and public tenders without visual fatigue.

## Colors

The palette establishes an immediate institutional atmosphere rooted in oceanic navy (`#0F2942`) and Fluminense civic azure (`#1B4965`). Primary functional surfaces are clean, anti-glare canvas tones (`#F8FAFC`) with crisp pure-white card containers (`#FFFFFF`) bound by structured, low-noise dividers (`#E2E8F0`).

### Semantic Anomaly & Risk Architecture
Chromatic accents are strictly functional and reserved for data telemetry, cluster classification, and risk flagging:
- **Integrity / Low Suspicion (`#059669`)**: Confirmed normal distribution, regularized bidding thresholds, clean audit history.
- **Moderate Variance / Attention (`#D97706`)**: Statistical price outlier beyond 1.5 IQR, sole-bidder emergency contracts, single-source dependency.
- **High Suspicion / Anomaly (`#DC2626`)**: Severe Isolation Forest outlier, recurrent direct awards immediately below bidding ceilings, shell-company flags.
- **Critical Violation (`#991B1B`)**: Active suspension overlaps, sanction breaches, confirmed overpricing.
- **Algorithmic Cluster Highlight (`#7C3AED`)**: K-Means centroid grouping markers and elbow point markers.

### Institutional Badges
Dedicated identifiers provide immediate visual anchors across state secretariats: Health (`#0284C7`), Education (`#EA580C`), UERJ (`#0D9488`), and Public Security/Police (`#334155`).

## Typography

Typography is bifurcated by purpose: **Inter** handles narrative, hierarchy, navigation, and structural labeling, while **JetBrains Mono** delivers machine precision for financial values (BRL currency), fiscal document keys (CNPJ/CPF), procurement contract hashes, and machine learning telemetry (Silhouette Scores, Inertia, P-values).

### Tabular Formatting Rules
All instances of currency, legal IDs, contract codes, and statistical metrics must enforce tabular figures (`font-variant-numeric: tabular-nums`) via JetBrains Mono. This eliminates jitter across analytical sortings, real-time filtering, and dense ledger columns.

Headlines employ tight negative tracking to maintain punch and economy of space on dense analytical screens, while metadata labels use uppercase tracking (`letter-spacing: 0.05em`) to ensure legibility at scale `0.6875rem` - `0.75rem`.

## Layout & Spacing

The layout follows an information-dense, enterprise-grade grid system engineered for forensic data analysis. The primary workspace utilizes a **fluid 12-column grid** anchored to a maximum container width of `1600px` for multi-pane analytical dashboards, collapsing into targeted configurations across viewports.

### Responsive Breakpoints & Mechanics
- **Desktop (>= 1280px)**: 12-column fluid grid. Collapsible left-hand query & parameter rail (280px fixed width). Primary content area adapts fluidly with `gutter-desktop` (1.5rem / 24px) and `margin-desktop` (2rem / 32px).
- **Tablet (768px - 1279px)**: 8-column layout with 1.5rem margins. Filter panels collapse into an off-canvas drawer or top horizontal filter strip. Charts re-orient from side-by-side matrices into stacked pairs.
- **Mobile (< 768px)**: 4-column layout with 1rem margins. Data tables switch to card lists or activate horizontal scroll with frozen primary identification columns (e.g., CNPJ / Supplier Name).

### Spacing Rhythm
Spacing is compact and mathematical. Vertical gaps inside data rows use `space-xs` (4px) to `space-sm` (8px), card container interior padding uses `space-lg` (16px), and high-level analytical section gaps standardise on `space-xl` (24px).

## Elevation & Depth

Visual depth is achieved primarily through **low-contrast outlines, micro-borders, and tonal layering**, strictly avoiding theatrical drop shadows which compromise visual density and precision in data-heavy UIs.

### Tonal Hierarchy
- **Canvas Base**: `#F8FAFC` provides a neutral, glare-resistant work surface.
- **Containers & Data Cards**: `#FFFFFF` with a crisp `1px solid #E2E8F0` hairline border.
- **Hovered Table Rows / Sub-containers**: `#F1F5F9` to indicate interactive context.
- **Floating Overlays & Tooltips**: `#0F2942` solid dark surface with `#FFFFFF` text for analytical chart tooltips (Pareto thresholds, scatter point coordinates), using an ultra-subtle ambient shadow: `0 4px 12px -2px rgba(15, 41, 66, 0.12), 0 2px 4px -1px rgba(15, 41, 66, 0.06)`.
- **Active / Focused Interactive Elements**: Replaced with clean 2px focus rings in `#1B4965` (Civic Azure) with 1px white offset.

## Shapes

The design system adopts a **Soft (`1`)** shape language (`0.25rem` / `4px` default radius; `0.5rem` / `8px` for larger cards and modal surfaces).

This crisp, disciplined geometric structure preserves the seriousness of judicial and fiscal oversight. It maximizes usable internal pixel area within dense tables, chart viewports, and multi-input query matrices. Circular pill shapes are used exclusively for small status indicators, live telemetry dots, and discrete filter pills to provide immediate differentiation from input controls and cards.

## Components

### Buttons
- **Primary Action (Export Audit, Run ML Model)**: Background `#0F2942`, text `#FFFFFF`, radius `4px`, font `Inter` 14px weight 600. Hover: `#1B4965`. Focus ring: 2px `#1B4965`.
- **Secondary / Action Tooling**: Background `#FFFFFF`, border `1px solid #CBD5E1`, text `#0F2942`. Hover: background `#F8FAFC`, border `#94A3B8`.
- **Destructive / Flag Suspect**: Background `#DC2626`, text `#FFFFFF`. Hover: `#B91C1C`.
- **Dense Table Actions**: Height 28px, font size 12px, padding `0 8px`, compact icon-only or icon-text variants.

### Badges & Risk Tags
- **Risk Indicator Tag**: Monospaced JetBrains Mono 11px uppercase badge. 
  - *Low*: Background `#ECFDF5`, border `1px solid #A7F3D0`, text `#065F46`.
  - *Medium*: Background `#FFFBEB`, border `1px solid #FDE68A`, text `#92400E`.
  - *High*: Background `#FEF2F2`, border `1px solid #FECACA`, text `#991B1B`.
  - Includes a 6px solid colored dot prefix signaling active anomaly state.
- **Organ Badges (Gov RJ)**: Low-saturation pill (`#F1F5F9`) with a 2px vertical indicator stripe using the Secretariat color (e.g., Saúde `#0284C7`, UERJ `#0D9488`).

### Data Tables (Audit Ledger)
- **Header Cell**: Height 36px, background `#F8FAFC`, text `#64748B`, font Inter 11px uppercase, font weight 600, border bottom `1px solid #CBD5E1`.
- **Data Cell**: Height 40px (compact mode: 32px), font JetBrains Mono 13px for metrics/dates/IDs and Inter 13px for entity names. Border bottom `1px solid #F1F5F9`.
- **Row States**: Hover `#F8FAFC`. Flagged/Anomalous row: Left-border highlight `3px solid #DC2626` and soft crimson background tint (`rgba(220, 38, 38, 0.03)`).

### Input Fields & Filter Controls
- Height 36px (compact), background `#FFFFFF`, border `1px solid #CBD5E1`, radius `4px`.
- Placeholder text `#94A3B8`.
- Integrated token/chip input for multi-selection of suppliers, NCM codes, and bidding modalities (Dispensa de Licitação, Pregão Eletrônico).

### Scientific & Analytical Visualizations
- **Elbow Method & Line Charts**: Gridlines `#F1F5F9`, primary curve `#1B4965` (2px stroke), optimal k-cluster marker marked by an amber `#D97706` vertical dashed reference line with hover callout.
- **Scatter Plots (Anomaly Detection)**: Baseline clusters in muted slate (`#94A3B8` at 40% opacity); outliers detected by Isolation Forest highlighted with ruby discs (`#DC2626`) surrounded by a translucent warning pulse ring.
- **Pareto Concentration Cards**: Displaying cumulative supplier percentages alongside an 80/20 threshold benchmark rule. Metric header rendered in `metric-display` JetBrains Mono with auxiliary variance indicators.